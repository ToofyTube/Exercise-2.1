import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Please enter celsius");
        //askes person to enter celsius
        Scanner input = new Scanner(System.in);
        double celsius = input.nextDouble();
        //program will take what the person enters and named it after celsius
        double fahrenheit = (9.0 / 5 * celsius + 32) ;
        //fahrenheit = 9/5*celsius+32
        System.out.println( celsius + " C is equal to " + fahrenheit + " F");
        //Print store string (celsius) " C is equal to " store string (fahrenhei) " F"
        
    }
}
